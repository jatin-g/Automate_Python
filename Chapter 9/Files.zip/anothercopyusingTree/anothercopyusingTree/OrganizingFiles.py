#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 20 20:36:04 2017

@author: Jatin
"""

import os, shutil

os.getcwd()